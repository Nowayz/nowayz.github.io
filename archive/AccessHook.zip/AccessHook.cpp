#include "AccessHook.h"
#include <Windows.h>

// This is not THREAD SAFE!  It could be made thread safe very easily, however.
// If the code being hooked is heavily multi-threaded then atomic operations should be considered for array access.

#define EFLAGS_TRACE 0x100
#define DEBUGCTL_BTF 0b10
#define DEBUGCTL_LBR 0b1
#define DR7_BTF 0b1000000000
#define DR7_LBR 0b100000000
#define ARRAY_SIZE(array) (sizeof((array))/sizeof((array[0])))

#define MAX_HOOKS 24

namespace AccessHook
{
	void* PageHookedBase[MAX_HOOKS]  = { 0 };
	void* HookedAddresses[MAX_HOOKS] = { 0 };
	void* HookFunction[MAX_HOOKS]    = { 0 };
	int   SkipHook[MAX_HOOKS]        = { 0 };

	void* GetHookFunction(void* addr) {
		for (int i = 0; i < ARRAY_SIZE(HookedAddresses); i++) {
			if (HookedAddresses[i] == addr) {
				return HookFunction[i];
			}
		}
		return NULL;
	}

	int IsHookedPage(void* page_addr) {
		for (int i = 0; i < ARRAY_SIZE(PageHookedBase); i++) {
			if (PageHookedBase[i] == page_addr) {
				return true;
			}
		}
		return false;
	}

	void AddHookedPageBase(void* page_base) {
		for (int i = 0; i < ARRAY_SIZE(PageHookedBase); i++) {
			if (PageHookedBase[i] == NULL) {
				PageHookedBase[i] = page_base;
				break;
			}
		}
	}

	void RemoveHookedPageBase(void* page_base) {
		for (int i = 0; i < ARRAY_SIZE(PageHookedBase); i++) {
			if (PageHookedBase[i] == page_base) {
				PageHookedBase[i] = NULL;
			}
		}
	}

	void AddHookedAddress(void* hook_addr, void* func_addr) {
		for (int i = 0; i < ARRAY_SIZE(HookedAddresses); i++) {
			if (HookedAddresses[i] == NULL) {
				HookedAddresses[i] = hook_addr;
				HookFunction[i] = func_addr;
				SkipHook[i] = FALSE;
				break;
			}
		}
	}

	void RemoveHookedAddress(void* hook_addr) {
		for (int i = 0; i < ARRAY_SIZE(HookedAddresses); i++) {
			if (HookedAddresses[i] == hook_addr) {
				HookedAddresses[i] = NULL;
				HookFunction[i] = NULL;
			}
		}
	}

	void SkipNextFunctionHook(void* hook_addr) {
		for (int i = 0; i < ARRAY_SIZE(HookedAddresses); i++) {
			if (HookedAddresses[i] == hook_addr) {
				SkipHook[i] = TRUE;
			}
		}
	}

	int ShouldSkipHook(void* hook_addr) {
		for (int i = 0; i < ARRAY_SIZE(HookedAddresses); i++) {
			if (HookedAddresses[i] == hook_addr) {
				if (SkipHook[i]) {
					SkipHook[i] = FALSE; // reset
					return TRUE;
				}
				else {
					return FALSE;
				}
			}
		}
	}

	void* GetPageBase(void* addr)
	{
		size_t addrtmp = (size_t)addr;
		return (void*)(addrtmp&~4095);
	}

	LONG WINAPI ExceptionFilter(EXCEPTION_POINTERS* pExceptionInfo)
	{
		DWORD dwtmp;
		thread_local static void* lastExceptionAddress = NULL;
		if (pExceptionInfo->ExceptionRecord->ExceptionCode == STATUS_ACCESS_VIOLATION) { // Entering hook region
			void* ripRegionBase = GetPageBase((void*)pExceptionInfo->ContextRecord->Rip);
			if (IsHookedPage(ripRegionBase)) {
                lastExceptionAddress = (void*)pExceptionInfo->ContextRecord->Rip;
                
                void* hookFunc = GetHookFunction((void*)pExceptionInfo->ContextRecord->Rip);
				if (hookFunc) { // Currently on hooked address
					if (!ShouldSkipHook((void*)pExceptionInfo->ContextRecord->Rip)) {
						pExceptionInfo->ContextRecord->Rip = (DWORD64)hookFunc;
						return EXCEPTION_CONTINUE_EXECUTION;
					}
				}

				VirtualProtect(ripRegionBase, 1, PAGE_EXECUTE_READ, &dwtmp);
				pExceptionInfo->ContextRecord->EFlags       |= EFLAGS_TRACE;
				pExceptionInfo->ContextRecord->Dr7          |= DR7_BTF;      // Faster stepping  (not required to operate)
                pExceptionInfo->ContextRecord->DebugControl |= DEBUGCTL_BTF; // Faster stepping  (not required to operate)
				return EXCEPTION_CONTINUE_EXECUTION;
			}
		} 
		else if (pExceptionInfo->ExceptionRecord->ExceptionCode == STATUS_SINGLE_STEP) { // Step through region, and handle exit from region
			void* ripRegionBase = GetPageBase((void*)pExceptionInfo->ContextRecord->Rip);
			void* lastExceptionRegionBase = GetPageBase(lastExceptionAddress);
			if (IsHookedPage(ripRegionBase) || IsHookedPage(lastExceptionRegionBase)) {
				if (ripRegionBase != lastExceptionRegionBase) { // Exiting hook region (occurs upon entry of another page); set memory access trap
					VirtualProtect(lastExceptionRegionBase, 1, PAGE_READONLY, &dwtmp);
					pExceptionInfo->ContextRecord->EFlags &= ~EFLAGS_TRACE;
				}
				else { // Trapped and in hook region, continue stepping
					lastExceptionAddress = (void*)pExceptionInfo->ContextRecord->Rip;
					pExceptionInfo->ContextRecord->EFlags |= EFLAGS_TRACE;
				}
				return EXCEPTION_CONTINUE_EXECUTION;
			}
		}
		return EXCEPTION_CONTINUE_SEARCH;
	}

	void Add(void* hook_addr, void* func_addr)
	{
		static int first_run = 1;
		if (first_run--) {
			AddVectoredExceptionHandler(true, ExceptionFilter);
		}

		void* hookRegionBase = GetPageBase(hook_addr);
		if (!IsHookedPage(hookRegionBase)) {
			AddHookedPageBase(hookRegionBase);
		}
		AddHookedAddress(hook_addr, func_addr);

		DWORD dwtmp;
		VirtualProtect(hookRegionBase, 1, PAGE_READONLY, &dwtmp);
	}

	void Remove(void* hook_addr)
	{
		RemoveHookedAddress(hook_addr);
		void* hookRegionBase = GetPageBase(hook_addr);
		for (int i = 0; i < ARRAY_SIZE(HookedAddresses); i++) {
			if (GetPageBase(HookedAddresses[i]) == hookRegionBase)
				goto skip_page_unhook;
		}
		DWORD dwtmp;
		VirtualProtect(hookRegionBase, 1, PAGE_EXECUTE_READ, &dwtmp);
		RemoveHookedPageBase(hookRegionBase);
	skip_page_unhook:;
	}
}