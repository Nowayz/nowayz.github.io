//========= Property of 3rdEra.com, All rights reserved. ============//
// Contributers: Phillip McNallen
// Name: AccessHook
//=============================================================================//
#pragma once

// Macro to call bypassing a function hook function (or just call SkipNextFunctionHook before calling the API you want)
#define HOOK_BYPASS(func, ...)  SkipNextFunctionHook(func); auto ret = func(__VA_ARGS__);
#define HOOK_BYPASS_NORET(func, ...)  SkipNextFunctionHook(func); func(__VA_ARGS__);

namespace AccessHook
{
	void SkipNextFunctionHook(void* hook_addr);
	void Add(void* hook_addr, void* func_addr);
	void Remove(void* hook_addr);
}

/*
Notes:
	By using PAGE_READONLY instead of PAGE_NOACCESS it should prevent the need to handle exceptions where the application attempts to read its own memory
	and causes an access violation in a page that is not the page where the desired hook resides.
	There would need to be a trap flag to handle every attempted read on the memory if using PAGE_NOACCESS.

	I seem to remember some Windows configurations not changing the page table entry nx bit upon VirtualProtect being called and thus still allowing execution when PAGE_READONLY is set.
	With current tests I have not encountered this issue again.
*/